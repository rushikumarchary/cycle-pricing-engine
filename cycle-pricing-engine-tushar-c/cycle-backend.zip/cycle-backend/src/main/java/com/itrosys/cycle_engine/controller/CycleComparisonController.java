package com.itrosys.cycle_engine.controller;

import com.itrosys.cycle_engine.dto.CartResponse;
import com.itrosys.cycle_engine.service.CycleComparisonService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/comparisons")
public class CycleComparisonController {

    private final CycleComparisonService cycleComparisonService;

    public CycleComparisonController(CycleComparisonService cycleComparisonService) {
        this.cycleComparisonService = cycleComparisonService;
    }

    @PostMapping("/add")
    public ResponseEntity<String> addComparison(@RequestParam Long cartId, 
                                                @RequestParam Long userId,
                                                @RequestBody(required = false) CartResponse cartResponse) {
        try {
            cycleComparisonService.addCompare(cartId, userId);
            return ResponseEntity.ok("Comparison added successfully.");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        }
    }
}
