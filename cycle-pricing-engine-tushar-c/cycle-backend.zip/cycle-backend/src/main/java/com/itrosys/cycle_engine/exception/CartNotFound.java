package com.itrosys.cycle_engine.exception;

public class CartNotFound extends RuntimeException{
    public CartNotFound(String message) {
        super(message);
    }
}
