package com.itrosys.cycle_engine.service;

import com.itrosys.cycle_engine.dto.CartRequest;
import com.itrosys.cycle_engine.dto.CartResponse;
import com.itrosys.cycle_engine.entity.*;
import com.itrosys.cycle_engine.enums.VariantType;
import com.itrosys.cycle_engine.repository.*;

import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Service
public class CycleComparisonService {

    private final UserRepository userRepository;
    private final CartRepository cartRepository;
    private final CycleComparisonRepository cycleComparisonRepository;

    public CycleComparisonService(UserRepository userRepository, CartRepository cartRepository,
                                  CycleComparisonRepository cycleComparisonRepository) {
        this.userRepository = userRepository;
        this.cartRepository = cartRepository;
        this.cycleComparisonRepository = cycleComparisonRepository;
    }

    @Transactional
    public void addCompare(Long cartId, Long userId) {
        // Fetch user and cart
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        Cart cart = cartRepository.findById(cartId)
                .orElseThrow(() -> new RuntimeException("Cart not found"));
        
     
        
        // VariantType variantType = determineVariant(cart);

        // // Fetch the corresponding Variant entity
        // Variant variant = variantRepository.findByName(variantType)
        //         .orElseThrow(() -> new RuntimeException("Variant not found for " + variantType));

        // Create and save comparison entry
        CycleComparison cycleComparison = new CycleComparison();
        cycleComparison.setUser(user);
        cycleComparison.setCart(cart);
     //   cycleComparison.setVariant(variant); 

        cycleComparisonRepository.save(cycleComparison);
    }

    private VariantType determineVariant(CartResponse cartResponse) {
        // Extract Frame material from cartResponse.parts
        String frameMaterial = Optional.ofNullable(cartResponse.getParts())
                .map(parts -> parts.get("Frame"))  // Get "Frame" object (Map<String, Object>)
                .map(frame -> frame.get("itemName")) // Get "itemName" value (Object)
                .filter(String.class::isInstance) // Ensure it's a String
                .map(String.class::cast) // Cast to String
                .orElse("standard"); // Default to "standard" if missing

        // Map to VariantType
        return switch (frameMaterial.toLowerCase()) {
            case "steel" -> VariantType.STANDARD;
            case "aluminum" -> VariantType.DELUXE;
            case "carbon fiber" -> VariantType.PREMIUM;
            default -> VariantType.STANDARD;
        };
    }
}