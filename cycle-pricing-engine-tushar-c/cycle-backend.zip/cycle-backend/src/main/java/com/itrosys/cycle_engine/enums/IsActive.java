package com.itrosys.cycle_engine.enums;

public enum IsActive {
    Y, N
}
