package com.itrosys.cycle_engine.exception;

public class DuplicateBrand extends RuntimeException {
    public DuplicateBrand(String message) {
        super(message);
    }
}
