package com.itrosys.cycle_engine.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.itrosys.cycle_engine.entity.CycleComparison;

import java.util.List;

public interface CycleComparisonRepository extends JpaRepository<CycleComparison, Long> {
}
