package com.itrosys.cycle_engine.dto;

import lombok.*;

import java.util.List;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CycleComparisonRequest {

    private Long userId;
    private List<Long> cartIds;
}
