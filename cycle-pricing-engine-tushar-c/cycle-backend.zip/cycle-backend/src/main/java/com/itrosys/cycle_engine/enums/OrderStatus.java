package com.itrosys.cycle_engine.enums;

public enum OrderStatus {
    Pending, Processing, Confirmed, Shipped, Cancel
}
