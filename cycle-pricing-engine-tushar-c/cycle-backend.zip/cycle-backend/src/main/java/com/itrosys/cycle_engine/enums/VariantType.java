package com.itrosys.cycle_engine.enums;

public enum VariantType {
     STANDARD, DELUXE, PREMIUM
}