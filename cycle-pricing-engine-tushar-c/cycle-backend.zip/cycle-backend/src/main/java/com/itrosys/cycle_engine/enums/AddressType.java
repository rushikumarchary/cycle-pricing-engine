package com.itrosys.cycle_engine.enums;

    public enum AddressType {
        HOUSE, APARTMENT, BUSINESS, OTHER
    }
