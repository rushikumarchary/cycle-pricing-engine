package com.itrosys.cycle_engine.dto;

import lombok.*;

import java.util.List;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CycleComparisonResponse {

    private Long comparisonId;
    private Long userId;
    private List<Long> cartIds;
}
