package com.itrosys.cycle_engine.exception;

public class InvalidDateFormat extends RuntimeException {
    public InvalidDateFormat(String s) {
        super(s);
    }
}
