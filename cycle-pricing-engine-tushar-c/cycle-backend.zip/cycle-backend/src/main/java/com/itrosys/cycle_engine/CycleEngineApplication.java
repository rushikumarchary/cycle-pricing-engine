package com.itrosys.cycle_engine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CycleEngineApplication {

	public static void main(String[] args) {
		SpringApplication.run(CycleEngineApplication.class, args);
	}

}
